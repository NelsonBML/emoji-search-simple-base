import "./App.css";
import Line from "./components/Line";
import emojis from "./emojis.json";

function App() {
  return (
    <div className="container">
      ici
    </div>
  );
}

export default App;
