const Line = (props) => {
  return <div>une ligne</div>;
};

export default Line;
